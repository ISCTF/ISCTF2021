<?php
 echo "ISCTF{g9kov44avqh5kjkes8d990t1y}"
?>