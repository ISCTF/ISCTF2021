<?php
$flag = 'ISCTF{pHP_1s_ThE_6eST_1@n9V@Ge}';
?>