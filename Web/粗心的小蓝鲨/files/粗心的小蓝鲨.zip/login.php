<?php
	if (isset($_POST['username']) && isset($_POST['password'])) {
		$name=$_POST["username"]; 
		$pwd=$_POST["password"];
		$logined = true;
		$flag = 'XXXX';
		include("flag.php");

		if (!ctype_alpha($name)) {$logined = false;}
		if (!is_numeric($pwd) ) {$logined = false;}
		if (md5($name) != md5($pwd)) {$logined = false;}
		
		if ($logined){
			echo "<h1>"."login successful"."<p>".$flag;
		}else{
			echo "<h1>"."Login failed"."<p>"."The blue shark mocked you and threw a hint at you"."<p>";
			highlight_file(__FILE__);
		}
	}
?>