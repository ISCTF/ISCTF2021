<?php

$flag="ISCTF{ea2b37f4-ec87-4587-b11d-e55987dcb325}";

?>