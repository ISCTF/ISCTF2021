﻿<?php
//flag.php
//MF师傅告诉我file_get_contents这个函数能输出flag.php里面的内容
error_reporting(0);
class MF_is_cat{
    private $pop = "f00001111";
    public $MF = "miao~ miao~ miao~";
    function __construct(){
        $this->pop =new ISCTF();
    }

    function __destruct(){
        $this->pop->action();
    }
}

class ISCTF{
    function action(){
        echo "Welcome to ISCTF World!";
    }
}

class Show{
    var $test2;
    function action(){
       echo file_get_contents('f'.$this->test2.'g.php');
    }
}


if(isset($_POST['ISCTF'])){
    unserialize($_POST['ISCTF']);
    }else{
    $obj = new MF_is_cat();
    highlight_file(__FILE__);
    }
?> 