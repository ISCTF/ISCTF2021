<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>easy_sql</title>
		
		<style>
			.image{
				margin: 0;
				background-size:100% 100%
				background-repeat: no-repeat;
				background-image: url(bg.png);
			}
		</style>
	</head>
	<body class="image">
		<div align="center">
		<h1 style="color: aliceblue;">点击下面图片开始注入之旅</h1>
		
		<a href="login.php"><img src="sqlmap.jpg" style="width: 230px;height: 230px;"></a>
		</div>	
	</body>
</html>