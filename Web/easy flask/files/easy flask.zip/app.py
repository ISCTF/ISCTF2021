from flask import Flask
from flask import request
from flask import render_template_string
from flask import render_template
from config import config

app = Flask(__name__)
app.config.from_object(config['flag'])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/test/')
def test():
    return render_template('ssti.html')

@app.route('/wow/' )
def touch():
    code = request.args.get('id')
    html = '''
          <h3> %s <h3/>
    '''%(code)
    return render_template_string('wow,good job! '
                                  'ISCTF{233ew2de1s4s3gsxb1}'+
                                  'Nothing else here' + html )


if __name__ == '__main__':
    app.debug = True
    app.run()
