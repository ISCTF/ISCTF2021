from datetime import timedelta
class Config(object):
    DEBUG = True
    TESTING = False
    SECRET_KEY = "ISCTF{weLc0me_T22_Ssti1ll}"
    Flag = 'ISCTF{qwdwegegerg}'



class DevelopmentConfig(Config):
    DEBUG = True

class TestingConfig(Config):
    TESTING = True

class FlagConfig(Config):
    Flag='ISCTF{fake_flag}'

config = {
        'development': DevelopmentConfig,
        'default': DevelopmentConfig,
        'flag' : FlagConfig
    }