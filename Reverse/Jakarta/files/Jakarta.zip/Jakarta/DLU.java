import java.util.Scanner;
public class DLU {
	public static boolean checkFlag(String flag) {
		// Here is some code
	}

	public static void main(String[] args){
		Scanner sc = new Scanner( System.in );
		System.out.print( "input flag: " );
		String input = sc.next();
		if (checkFlag(input)) {
			System.out.println("correct!");
		}else {
			System.out.println("wrong flag!");
		}


	}
}
