需安装Java 8或以上，建议64位
启动器下载地址：http://hmcl.huangyuhui.net/download/