import random
from Crypto.Cipher import AES
import base64
def pad(data):
    data=data.encode('utf8')
    while len(data) % 16 !=0:
        data+=b'\x00'
    return data
def jiami(key,m):
    mode=AES.MODE_ECB
    aes=AES.new(pad(key),mode)
    en_m=aes.encrypt(pad(m))
    en_m=base64.encodebytes(en_m)
    en_m=en_m.decode('utf8')
    print(en_m)

with open('output.txt', 'w') as f:
    for i in range(624):
        f.write(str(random.getrandbits(32)) + "\n")
    f.close()
flag = 'ISCTF{XXXXXXXXXXX}'
key= str(random.getrandbits(32))
jiami(key,flag)


#BYIlzaPnImGZeWVpn+QudBiZEwlaA3H3rl69STD8/tQ=



